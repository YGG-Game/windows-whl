version = '0.71'
short_version = version
full_version = version
